import { test, expect } from "@playwright/test";
import { fixture } from "./quick-import.spec";

test("redesign offers working steps, filters, undo and a pinned action", async ({ page }) => {
  await fixture(page);
  await page.getByLabel("Import source").fill("subtle - тонкий - сатл\nbook - книга");
  await page.getByRole("button", { name: "Review import", exact: true }).click();
  await expect(page.getByRole("button", { name: "Undo", exact: true })).toBeVisible();
  await expect(page.getByRole("button", { name: "Issues 1", exact: true })).toBeVisible();
  await expect(page.getByRole("button", { name: "1 Input", exact: true })).toBeEnabled();
  await expect(page.getByRole("button", { name: "Revalidate", exact: true })).toHaveCount(0);
  await expect(page.getByText("Advanced", { exact: true })).toBeVisible();
  await expect(page.getByLabel("Difficulty", { exact: true })).not.toBeVisible();
  await expect(page.getByTestId("import-footer")).toBeVisible();
});
